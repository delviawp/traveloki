function checkLogin(req, res, next) {
    if (req.session.user) {
        next()
    } else {
        const obj = { email: '', password: '' }
        let errLogin = 'Anda tidak memiliki askes, silahkan login ke pbjs terdekat'
        res.render('login', {err: false, errLogin, obj, isRedirect: false})
    }
}

module.exports = checkLogin