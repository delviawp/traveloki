const nodemailer = require('nodemailer')
const { google } = require('googleapis')
const { OAuth2 } = google.auth
const dataUrlParser = require('./dataUrlParser')

const Mailing = {};

const oauth2Client = new OAuth2(
  process.env.GMAIL_OAUTH_CLIENT_ID,
  process.env.GMAIL_OAUTH_SECRET,
  process.env.OAUTH_PLAYGROUND
);

Mailing.sendEmail = (data, cb) => {
//   let { emailRecipients, subject, text, file } = data
  oauth2Client.setCredentials({
    refresh_token: process.env.GMAIL_REFRESH_KEY,
  });

  const accessToken = oauth2Client.getAccessToken()

  const smtpTransport = nodemailer.createTransport({
    service: 'gmail',
    auth: {
      type: 'OAuth2',
      user: process.env.GMAIL_SENDER,
      clientId: process.env.GMAIL_OAUTH_CLIENT_ID,
      clientSecret: process.env.GMAIL_OAUTH_SECRET,
      refreshToken: process.env.GMAIL_REFRESH_KEY,
      accessToken,
    },
  });

  const mailOptions = {
    from: process.env.GMAIL_SENDER,
    to: 'riankaryamarpaung@gmail.com',
    subject: 'subject',
    text: "test"
    // attachments: [
    //   {
    //   filename: "image.jpg",
    //   contentType:  'image/jpeg',
    //   content: dataUrlParser(file)
    //   }
    // ]
  };

  smtpTransport.sendMail(mailOptions, (err, info) => {
    if(err){
      cb(err, null)
    }else{
      cb(null, info)
    }
  }); 
}

module.exports = Mailing