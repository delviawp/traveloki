module.exports = (dataurl) => {
    return new Buffer(dataurl.split("base64,")[1], "base64")
}