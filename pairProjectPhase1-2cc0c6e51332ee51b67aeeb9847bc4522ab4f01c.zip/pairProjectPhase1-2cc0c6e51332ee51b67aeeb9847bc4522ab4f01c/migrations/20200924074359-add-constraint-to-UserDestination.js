'use strict';

module.exports = {
  up: (queryInterface, Sequelize) => {
    return Promise.all([
      queryInterface.addConstraint("UserDestinations", {
        fields: ["UserId"],
        type: "foreign key",
        name: "custom_fkey_UserId",
        references: { //Required field
          table: "Users",
          field: "id"
        },
        onDelete: "CASCADE",
        onUpdate: "CASCADE"
      }),
      queryInterface.addConstraint("UserDestinations", {
        fields: ["DestinationId"],
        type: "foreign key",
        name: "custom_fkey_DestinationId",
        references: { //Required field
          table: "Destinations",
          field: "id"
        },
        onDelete: "CASCADE",
        onUpdate: "CASCADE"
      })
    ])
  },

  down: (queryInterface, Sequelize) => {
    return Promise.all([
      queryInterface.removeConstraint("UserDestinations", "UserId"),
      queryInterface.removeConstraint("UserDestinations", "DestinationId")
    ])
  }
};
