const {Destination, User, UserDestination} = require('../models')

class Controller {
    static destinations(req, res) {
        Destination.findAll()
        .then(data => {
            let userSession = req.session.user
            data = data.map(elem => elem.helper())
            res.render('destination', {data, userSession})
        })
        .catch(err => res.send(err))
    }
    static addDestinations(req, res) {
        let UserId = req.session.user.id
        let DestinationId = req.params.id
        UserDestination.create({UserId, DestinationId})
        .then(data => {
            res.redirect('/destinations')
        })
    }
}

module.exports = Controller