const nodemailer = require('nodemailer');
const hashPassword = require('../helpers/hashPassword')
const { User, UserDestination, Destination } = require('../models')
const { sendEmail } = require('../helpers/mailer');
const { default: Axios } = require('axios');

class Controller {
    static homepage(req, res) {
        let userSession = req.session.user
        const obj = { first_name: '', last_name: '', birth_year: '', phone_number: '', gender: '' }
        res.render('homepage', { userSession, err: false, obj, isRedirect: false })
    }
    static submitRegister(req, res) {
        const { first_name, last_name, age, gender, phone_number, email, password, reTypePassword } = req.body
        const obj = { first_name, last_name, age, gender, phone_number, email, password, reTypePassword }
        User.create(obj)
            .then(() => res.redirect('/'))
            .catch(error => {
                let userSession = req.session.user
                let err = {}
                error.errors.forEach(elem => {
                    err[elem.path] = elem.message
                })
                res.render('homepage', { userSession, err, obj, isRedirect: true })
            })
    }
    static login(req, res) {
        let userSession = req.session.user
        const obj = { email: '', password: '' }
        res.render('login', { userSession, err: false, errLogin: false, obj, isRedirect: false })
    }
    static submitLogin(req, res) {
        const { email, password } = req.body
        const obj = { email, password }
        User.findOne({ where: { email: obj.email } })
            .then(data => {
                if (data == null) {
                    let userSession = req.session.user
                    let errLogin = 'Email/password tidak ditemukan'
                    res.render('login', { userSession, obj, err: false, errLogin, isRedirect: false })
                }

                let hash = hashPassword(obj.password)
                let passwordTrue = hash == data.password
                if (passwordTrue) {
                    req.session.user = {
                        email: data.email,
                        id: data.id,
                        role: data.role
                    }
                    if (data.role == 'Admin') {
                        res.redirect('/adminPage')
                    } else {
                        res.redirect('/destinations')
                    }
                } else {
                    let userSession = req.session.user
                    let errLogin = 'Email/password tidak ditemukan'
                    res.render('login', { userSession, obj, err: false, errLogin, isRedirect: false })
                }
            })
            .catch(err => res.send(err))
    }
    static logout(req, res) {
        req.session.destroy(() => {
            res.redirect('/login')
        })
    }
    static cart(req, res) {
        let id = req.session.user.id
        let quote = ''
        Axios({
            method: 'get',
            url: 'https://favqs.com/api/qotd'
        })
            .then(({ data }) => {
                quote = data.quote.body
                return User.findOne({ where: { id }, include: [Destination] })
            })
            .then(data => {
                let userSession = req.session.user
                let total = 0
                data = data.dataValues.Destinations.map(elem => {
                    return {
                        name: elem.name,
                        price: elem.price
                    }
                })
                data.forEach(elem => {
                    total += elem.price
                })


                res.render('cart', { quote, data, total, userSession })
            })
            .catch(err => res.send(err))
    }
    static admin(req, res) {
        Destination.findAll()
            .then(data => {
                let userSession = req.session.user
                data = data.map(elem => elem.helper())

                res.render('adminPage', { data, userSession })
            })
            .catch(err => res.send(err))
    }
    static adminEditForm(req, res) {
        const id = +req.params.id
        Destination.findOne({ where: { id }, include: [User] })
            .then(data => {
                let obj = { id, name: data.dataValues.name, price: data.dataValues.price }
                let users = data.dataValues.Users.map(elem => {
                    return {
                        id: elem.dataValues.id,
                        full_name: `${elem.dataValues.first_name} ${elem.dataValues.last_name}`
                    }
                })
                res.render('adminEdit', { obj, users, id, isRedirect: false, err: false })
            })
            .catch(err => res.send(err))
    }
    static submitAdminEditForm(req, res) {
        const { name, price } = req.body
        const obj = { name, price }
        const id = +req.params.id
        Destination.update(obj, { where: { id } })
            .then(() => {
                res.redirect('/adminPage')
            })
            .catch(error => {
                let err = {}
                error.errors.forEach(elem => {
                    err[elem.path] = elem.message
                })
                res.render('editcasts', { err, obj, isRedirect: true, id })
            })
    }
    static adminDeleteForm(req, res) {
        const id = +req.params.id
        Destination.destroy({where: {id}})
        .then(() => res.redirect('/adminPage'))
        .catch(err => res.send(err))
    }
    static adminAddForm(req, res) {
        const obj = {name: '', price: ''}
        res.render('addDestination', {err:false, obj, isRedirect:false})
    }
    static submitAdminAddForm(req, res) {
        const {name, price} = req.body
        const obj = {name, price}
        Destination.create(obj)
        .then(() => res.redirect('/adminPage'))
        .catch(error => {
            let err = {}
            error.errors.forEach(elem => {
                err[elem.path] = elem.message
            })
            res.render('addDestination', { err, obj, isRedirect: true })
        })
    }
    static adminDeleteUser(req, res) {
        UserDestination.destroy({where: {UserId: req.params.id, DestinationId: req.params.desId}})
        .then(() => res.redirect(`/adminPage/${req.params.desId}/edit`))
        .catch(err => res.send(err))
    }
}

module.exports = Controller