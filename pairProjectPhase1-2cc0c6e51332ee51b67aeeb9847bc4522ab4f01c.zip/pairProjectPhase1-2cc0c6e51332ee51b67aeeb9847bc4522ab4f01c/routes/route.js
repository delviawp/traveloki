const router = require('express').Router()
const destination = require('./routeDestination')
const Controller = require('../controllers/controller')
const app = require('express')()
const session = require('express-session')
const checkLogin = require('../middlewares/checkLogin')

app.set('trust proxy', 1)
app.use(session({
  secret: 'keyboard cat',
  resave: false,
  saveUninitialized: true,
  cookie: { secure: false }
}))

router.get('/', Controller.homepage)
router.post('/', Controller.submitRegister)
router.get('/login', Controller.login)
router.post('/login', Controller.submitLogin)
router.get('/logout', Controller.logout)
router.get('/cart', checkLogin, Controller.cart)
router.get('/adminPage', Controller.admin)
router.get('/adminPage/:id/edit', Controller.adminEditForm)
router.post('/adminPage/:id/edit', Controller.submitAdminEditForm)
router.get('/adminPage/:id/delete', Controller.adminDeleteForm)
router.get('/adminPage/add', Controller.adminAddForm)
router.post('/adminPage/add', Controller.submitAdminAddForm)
router.get('/users/:id/:desId/delete', Controller.adminDeleteUser)

router.use('/destinations', destination)

module.exports = router