const router = require('express').Router()
const Controller = require('../controllers/destinationController')

router.get('/', Controller.destinations)
router.get('/:id/add', Controller.addDestinations)

module.exports = router