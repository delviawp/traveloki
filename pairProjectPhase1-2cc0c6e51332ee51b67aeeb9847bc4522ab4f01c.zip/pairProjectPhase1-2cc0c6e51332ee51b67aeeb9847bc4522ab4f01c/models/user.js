'use strict';
const hashPassword = require('../helpers/hashPassword')
const {
  Model, cast
} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class User extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      User.belongsToMany(models.Destination, {through: models.UserDestination})
      User.hasMany(models.UserDestination)
    }
  };
  User.init({
    first_name: {
      type: DataTypes.STRING,
      validate: {
        customValidator(value) {
          let reg = new RegExp(/^[a-zA-Z]+$/)
          if (value === '') {
            throw new Error('Fist Name harus diisi')
          } else if (!reg.test(value)) {
            throw new Error('Fist Name hanya boleh menggunakan huruf')
          }
        }
      }
    },
    last_name: {
      type: DataTypes.STRING,
      validate: {
        customValidator(value) {
          let reg = new RegExp(/^[a-zA-Z]+$/)
          if (value === '') {
            throw new Error('Last Name harus diisi')
          } else if (!reg.test(value)) {
            throw new Error('Last Name hanya boleh menggunakan huruf')
          }
        }
      }
    },
    age: {
      type: DataTypes.INTEGER,
      validate: {
        customValidator(value) {
          let reg = new RegExp(/^[0-9]+$/)
          if (value === '') {
            throw new Error('Age harus diisi')
          } else if (!reg.test(value)) {
            throw new Error('Age hanya boleh menggunakan angka')
          }
        }
      }
    },
    gender: DataTypes.STRING,
    phone_number: {
      type: DataTypes.STRING,
      validate: {
        customValidator(value) {
          let reg = new RegExp(/^[a-zA-Z0-9-+]+$/)
          if (value === '') {
            throw new Error('Phone Number harus diisi')
          } else if (!reg.test(value)) {
            throw new Error('Phone Number hanya boleh menggunakan huruf, angka, dan simbol "-" dan "+"')
          }
        }
      }
    },
    email: {
      type: DataTypes.STRING,
      validate: {
        customValidator(value) {
          let reg = new RegExp(/^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/)
          if (value === '') {
            throw new Error('Email harus diisi')
          } else if (!reg.test(String(value).toLowerCase())) {
            throw new Error('Format Email salah')
          }
        }
      }
    },
    password: {
      type: DataTypes.STRING,
      validate: {
        customValidator(value) {
          let reg = new RegExp(/^[a-zA-Z0-9]+$/)
          if (value === '') {
            throw new Error('Password harus diisi')
          } else if (!reg.test(value)) {
            throw new Error('Password hanya boleh menggunakan huruf dan angka')
          }
        }
      }
    },
    reTypePassword: {
      type: DataTypes.STRING,
      validate: {
        customValidator(value) {
          if (value === '') {
            throw new Error('Re-type Password harus diisi')
          } else if (value !== this.password) {
            throw new Error('Tidak sama dengan Password')
          }
        }
      }
    },
    isLoggedIn: DataTypes.BOOLEAN,
    role: DataTypes.STRING
  }, {
    sequelize,
    modelName: 'User',
  })
  User.beforeCreate((user, options) => {
    const hashedPassword = hashPassword(user.password)
    user.password = hashedPassword
    user.isLoggedIn = false
    user.role = 'User'
  })
  return User;
};