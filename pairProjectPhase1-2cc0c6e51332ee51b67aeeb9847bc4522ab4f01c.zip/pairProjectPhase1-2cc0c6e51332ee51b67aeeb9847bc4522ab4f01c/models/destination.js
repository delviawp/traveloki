'use strict';
const {
  Model
} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class Destination extends Model {
    helper() {
      return {
        id: this.dataValues.id,
        name: this.dataValues.name,
        price: this.dataValues.price
      }
    }
    static associate(models) {
      Destination.belongsToMany(models.User, {through: models.UserDestination})
      Destination.hasMany(models.UserDestination)
    }
  };
  Destination.init({
    name: DataTypes.STRING,
    price: DataTypes.INTEGER
  }, {
    sequelize,
    modelName: 'Destination',
  });
  return Destination;
};